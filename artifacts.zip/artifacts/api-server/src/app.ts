import express, { type Express } from "express";
import cors from "cors";
import type { NextFunction, Request, Response } from "express";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json({ limit: "256kb" }));
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

app.use(
  (
    error: unknown,
    req: Request,
    res: Response,
    _next: NextFunction,
  ): void => {
    const errorType =
      typeof error === "object" && error !== null && "type" in error
        ? error.type
        : undefined;

    if (errorType === "entity.too.large") {
      res.status(413).json({ error: "The chat request is too large." });
      return;
    }

    if (error instanceof SyntaxError) {
      res.status(400).json({ error: "The request body must be valid JSON." });
      return;
    }

    req.log.error({ err: error }, "Unhandled API error");
    res.status(500).json({
      error: "The server couldn't complete that request. Please try again.",
    });
  },
);

export default app;
