
import { Router, type IRouter } from "express";
import {
  ChatCompletionBody,
  ChatCompletionResponse,
} from "@workspace/api-zod";
import { GoogleGenAI } from "@google/genai";

const router: IRouter = Router();
const RATE_WINDOW_MS = 60_000;
const RATE_LIMIT = 20;
const MAX_CONVERSATION_CHARACTERS = 60_000;
const rateBuckets = new Map<string, { count: number; resetAt: number }>();

function isAllowedOrigin(origin: string, requestHostname: string): boolean {
  try {
    const parsedOrigin = new URL(origin);
    if (parsedOrigin.hostname === requestHostname) return true;

    const allowedOrigins = (process.env.OREA_ALLOWED_ORIGINS ?? "")
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean);

    return allowedOrigins.includes(parsedOrigin.origin);
  } catch {
    return false;
  }
}

function takeRateLimit(ip: string): {
  allowed: boolean;
  retryAfter: number;
} {
  const now = Date.now();
  let bucket = rateBuckets.get(ip);

  if (!bucket || bucket.resetAt <= now) {
    bucket = { count: 0, resetAt: now + RATE_WINDOW_MS };
    rateBuckets.set(ip, bucket);
  }

  if (rateBuckets.size > 10_000) {
    for (const [key, value] of rateBuckets) {
      if (value.resetAt <= now) rateBuckets.delete(key);
    }
  }

  if (bucket.count >= RATE_LIMIT) {
    return {
      allowed: false,
      retryAfter: Math.max(1, Math.ceil((bucket.resetAt - now) / 1000)),
    };
  }

  bucket.count += 1;
  return { allowed: true, retryAfter: 0 };
}

router.post("/chat", async (req, res): Promise<void> => {
  const origin = req.get("origin");

  if (origin && !isAllowedOrigin(origin, req.hostname)) {
    res.status(403).json({
      error:
        "This website isn't allowed to use the chat API. Add its origin to OREA_ALLOWED_ORIGINS.",
    });
    return;
  }

  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const limit = takeRateLimit(ip);

  if (!limit.allowed) {
    res.setHeader("Retry-After", String(limit.retryAfter));
    res.status(429).json({
      error: "Too many chat requests. Please wait a moment and try again.",
    });
    return;
  }

  const parsed = ChatCompletionBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({
      error: "Send a non-empty conversation with up to 40 messages.",
    });
    return;
  }

  const { messages } = parsed.data;
  const characterCount = messages.reduce(
    (total, message) => total + message.content.length,
    0,
  );

  if (characterCount > MAX_CONVERSATION_CHARACTERS) {
    res.status(400).json({
      error:
        "This conversation is too long to send. Start a new chat and try again.",
    });
    return;
  }

  if (messages[messages.length - 1]?.role !== "user") {
    res.status(400).json({
      error: "Add a user message before requesting an AI response.",
    });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY?.trim();

  if (!apiKey) {
    res.status(503).json({
      error: "OREA AI isn't configured yet. Add GEMINI_API_KEY in Replit Secrets.",
    });
    return;
  }

  try {
    const ai = new GoogleGenAI({ apiKey });

    const systemMessages = messages
      .filter((message) => message.role === "system")
      .map((message) => message.content);

    const conversation = messages
      .filter(
        (message) =>
          message.role === "user" || message.role === "assistant",
      )
      .map((message) => ({
        role: message.role === "assistant" ? "model" as const : "user" as const,
        parts: [{ text: message.content }],
      }));

    const response = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL?.trim() || "gemini-2.5-flash-lite",
      contents: conversation,
      config: {
        ...(systemMessages.length > 0
          ? { systemInstruction: systemMessages.join("\n\n") }
          : {}),
        maxOutputTokens: 2048,
      },
    });

    const reply = response.text?.trim() ?? "";

    if (!reply) {
      req.log.warn("Gemini returned an empty chat response");
      res.status(502).json({
        error: "The AI returned an empty response. Please try again.",
      });
      return;
    }

    res.json(ChatCompletionResponse.parse({ reply }));
  } catch (error) {
    req.log.warn({ err: error }, "Gemini request failed");

    const errorMessage =
      error instanceof Error ? error.message : "";

    if (/api.?key|unauthenticated|permission denied|forbidden/i.test(errorMessage)) {
      res.status(503).json({
        error: "Gemini rejected the API key. Check GEMINI_API_KEY in Replit Secrets.",
      });
      return;
    }

    if (/quota|resource.?exhausted|rate.?limit/i.test(errorMessage)) {
      res.status(429).json({
        error: "Gemini's available quota or rate limit has been reached. Try again later or check your AI Studio limits.",
      });
      return;
    }

    if (/timeout|deadline/i.test(errorMessage)) {
      res.status(504).json({
        error: "The AI took too long to respond. Please try again.",
      });
      return;
    }

    res.status(502).json({
      error: "OREA AI couldn't get a response from Gemini. Check the backend logs and try again.",
    });
  }
});

export default router;
