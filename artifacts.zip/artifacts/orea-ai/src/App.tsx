import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { AlertCircle, ArrowUp, Bot, MessageSquareText, Plus, ShieldCheck, Sparkles, Trash2, UserRound } from 'lucide-react';
import { getHealthCheckQueryKey, useChatCompletion, useHealthCheck, type ChatMessage } from '@workspace/api-client-react';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const STORAGE_KEY = 'orea-ai-conversation-v1';
const PROMPTS = [
  'Help me understand a complex topic, step by step',
  'What is a thoughtful way to approach a difficult decision?',
  'Give me a fresh perspective on something I am working on',
];

function getRecentContext(messages: ChatMessage[]): ChatMessage[] {
  let characters = 0;
  const context: ChatMessage[] = [];

  for (let index = messages.length - 1; index >= 0; index -= 1) {
    const message = messages[index];
    if (!message) continue;
    if (context.length > 0 && characters + message.content.length > 60000) break;
    context.unshift(message);
    characters += message.content.length;
  }

  return context;
}

function Home() {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const value: unknown = JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? '[]');
      if (!Array.isArray(value)) return [];
      return value.filter((entry): entry is ChatMessage =>
        typeof entry === 'object' && entry !== null &&
        ((entry as ChatMessage).role === 'user' || (entry as ChatMessage).role === 'assistant') &&
        typeof (entry as ChatMessage).content === 'string',
      ).slice(-40);
    } catch {
      return [];
    }
  });
  const [draft, setDraft] = useState('');
  const [requestError, setRequestError] = useState('');
  const transcriptRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const healthQuery = useHealthCheck({
    query: {
      queryKey: getHealthCheckQueryKey(),
      retry: 1,
      refetchOnWindowFocus: false,
    },
  });
  const chat = useChatCompletion();
  const isPending = chat.isPending;
  const serviceDown = healthQuery.isError;

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
    } catch {
      // Keep the live conversation usable if browser storage is unavailable.
    }
  }, [messages]);

  useEffect(() => {
    if (!transcriptRef.current) return;
    transcriptRef.current.scrollTo({ top: transcriptRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, isPending]);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (!textarea) return;
    textarea.style.height = '0px';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 180)}px`;
  }, [draft]);

  const submitPrompt = (event?: FormEvent<HTMLFormElement>) => {
    event?.preventDefault();
    const prompt = draft.trim();
    if (!prompt || prompt.length > 16000 || isPending) return;
    const history = messages.slice(-39);
    const pendingHistory = [...history, { role: 'user' as const, content: prompt }];
    const requestContext = getRecentContext(pendingHistory);
    setRequestError('');
    setMessages(pendingHistory);
    chat.mutate(
      { data: { messages: requestContext } },
      {
        onSuccess: (response) => {
          const reply = response.reply?.trim();
          if (!reply) {
            setMessages(history);
            setRequestError('OREA returned an empty reply. Your message is still here—please try again.');
            return;
          }
          setMessages([...pendingHistory, { role: 'assistant' as const, content: reply }].slice(-40));
          setDraft((current) => current === prompt ? '' : current);
          setRequestError('');
          window.requestAnimationFrame(() => textareaRef.current?.focus());
        },
        onError: (error) => {
          setMessages(history);
          setRequestError(getErrorMessage(error));
        },
      },
    );
  };

  const startFresh = () => {
    if (isPending) return;
    setMessages([]);
    setDraft('');
    setRequestError('');
    textareaRef.current?.focus();
  };

  const onKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) {
      event.preventDefault();
      submitPrompt();
    }
  };

  return (
    <div className="app-shell">
      <aside className="rail" aria-label="OREA AI">
        <div className="brand">
          <div className="brand-mark" aria-hidden="true"><Sparkles size={19} strokeWidth={1.8} /></div>
          <div className="brand-name">OREA <span className="brand-ai">AI</span></div>
        </div>
        <div className="rail-section">
          <div className="rail-caption">Your space</div>
          <div className="rail-thread" data-testid="text-current-conversation">
            <MessageSquareText size={15} />
            <span>{messages.length ? 'A conversation in progress' : 'A new conversation'}</span>
          </div>
        </div>
        <div className="rail-foot">
          <div className="rail-foot-rule" />
          <div className="rail-note"><strong>A little room to think.</strong><br />Ask naturally. OREA keeps the thread in context.</div>
        </div>
      </aside>

      <main className="main-panel">
        <header className="topbar">
          <div className="mobile-brand">
            <span className="brand-mark" aria-hidden="true"><Sparkles size={17} /></span>
            <span>OREA <span className="brand-ai">AI</span></span>
          </div>
          <div className="top-context" data-testid="status-service">
            <span className={`status-dot${serviceDown ? ' offline' : ''}`} />
            <span>{healthQuery.isLoading ? 'Connecting to OREA' : serviceDown ? 'Service unavailable' : 'Ready when you are'}</span>
          </div>
          <div className="top-actions">
            <button className="icon-button" type="button" onClick={startFresh} disabled={isPending || messages.length === 0 && !draft} data-testid="button-new-chat" aria-label="Start a new conversation">
              <Plus size={15} /><span className="clear-label">New conversation</span>
            </button>
            {messages.length > 0 && <button className="icon-button" type="button" onClick={startFresh} disabled={isPending} data-testid="button-clear-chat" aria-label="Clear conversation">
              <Trash2 size={15} /><span className="clear-label">Clear</span>
            </button>}
          </div>
        </header>

        <section className="chat-area" aria-label="Conversation with OREA AI">
          <div className="conversation" ref={transcriptRef} data-testid="region-conversation" aria-live="polite">
            {messages.length === 0 ? (
              <div className="welcome">
                <div className="welcome-kicker">A thinking partner, at your pace</div>
                <h1>Start anywhere.<br /><em>Find your way.</em></h1>
                <p className="welcome-copy">Bring a question, a half-formed idea, or something you want to see more clearly. We can work through it together.</p>
                <div className="suggestions-label">A few places to begin</div>
                <div className="suggestions">
                  {PROMPTS.map((prompt) => (
                    <button className="suggestion" key={prompt} type="button" onClick={() => { setDraft(prompt); textareaRef.current?.focus(); }} data-testid={`button-suggestion-${PROMPTS.indexOf(prompt)}`}>
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="message-list">
                {messages.map((message, index) => (
                  <article className={`message ${message.role}`} key={`${index}-${message.role}`} data-testid={`message-${message.role}-${index}`}>
                    <div className="message-mark" aria-hidden="true">
                      {message.role === 'assistant' ? <Bot size={17} /> : <UserRound size={16} />}
                    </div>
                    <div>
                      <div className="message-meta"><span className="message-name">{message.role === 'assistant' ? 'OREA' : 'You'}</span></div>
                      <div className="message-body" data-testid={`text-message-${index}`}>{message.content}</div>
                    </div>
                  </article>
                ))}
                {isPending && <div className="message assistant" data-testid="status-response-loading">
                  <div className="message-mark"><Bot size={17} /></div>
                  <div><div className="message-meta"><span className="message-name">OREA</span></div><div className="loading-dots" aria-label="OREA is thinking"><span /><span /><span /></div></div>
                </div>}
              </div>
            )}
          </div>

          {serviceDown && <div className="error-banner" role="status" data-testid="status-health-error">
            <AlertCircle size={16} />
            <span>OREA's service could not be reached. Check that the API server is running and configured, then try your message again.</span>
          </div>}
          {requestError && <div className="error-banner" role="alert" data-testid="status-chat-error">
            <AlertCircle size={16} /><span>{requestError}</span>
          </div>}

          <div className="composer-wrap">
            <form className="composer" onSubmit={submitPrompt} data-testid="form-chat">
              <textarea
                ref={textareaRef}
                value={draft}
                onChange={(event) => { setDraft(event.target.value); if (requestError) setRequestError(''); }}
                onKeyDown={onKeyDown}
                placeholder="Ask anything, or keep exploring..."
                aria-label="Message OREA AI"
                rows={1}
                maxLength={16000}
                disabled={isPending}
                data-testid="input-chat-message"
              />
              <button className="send-button" type="submit" disabled={!draft.trim() || draft.length > 16000 || isPending} aria-label="Send message" data-testid="button-send-message">
                <ArrowUp size={19} strokeWidth={2.2} />
              </button>
            </form>
            <div className="composer-bottom"><span className="composer-hint">Enter to send · Shift + Enter for a new line</span><span className="composer-hint">{draft.length.toLocaleString()} / 16,000</span></div>
            <p className="disclaimer"><ShieldCheck size={11} style={{ verticalAlign: '-2px', marginRight: 4 }} />Your conversation stays on this device when you return.</p>
          </div>
        </section>
      </main>
    </div>
  );
}

function getErrorMessage(error: unknown): string {
  if (typeof error === 'object' && error !== null && 'data' in error) {
    const data = error.data;
    if (typeof data === 'object' && data !== null && 'error' in data && typeof data.error === 'string') {
      return data.error;
    }
  }
  if (typeof error === 'object' && error !== null && 'error' in error && typeof error.error === 'string') {
    return error.error;
  }
  if (error instanceof Error && error.message) {
    if (/fetch|network|failed to/i.test(error.message)) {
      return 'OREA could not connect to the chat service. Check the API server and model configuration, then try again.';
    }
    return error.message;
  }
  return 'OREA could not complete that response. Your conversation is safe—please try again.';
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
